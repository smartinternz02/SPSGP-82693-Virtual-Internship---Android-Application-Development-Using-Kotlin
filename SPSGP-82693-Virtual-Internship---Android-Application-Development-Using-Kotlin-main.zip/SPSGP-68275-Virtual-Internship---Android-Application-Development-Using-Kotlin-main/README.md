# SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin
Virtual Internship - Android Application Development Using Kotlin

## Name: Bollepalli Sri Sai Hemanth

⏩ [Main Project 1](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Nearby-Places-Finder)  And [Main Project 2](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Grocery%20App)

⏩ [Google Developer Profile](https://g.dev/sshemanth)

### All Android Projects:

* [Lemonade App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Lemonade-App)

* [Dogglers App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Dogglers-App)

* [Lunch Tray App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/LunchTray-App)

* [Amphibians App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Amphibians-App)

* [Forage App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/Forage-App)

* [Water Me App](https://github.com/smartinternz02/SPSGP-68275-Virtual-Internship---Android-Application-Development-Using-Kotlin/tree/main/WaterMe-App)









